truffle console

c = await Color.deployed()
c.mint("aa")

